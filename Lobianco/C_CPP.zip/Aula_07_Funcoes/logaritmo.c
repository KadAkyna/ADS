#include <stdio.h>
#include <math.h>

int main(void)
{
   printf("O logaritmo natural de 256.0 é %f\n", log(256.0));
   printf("O Log10 de 100 é %f\n", log10(100.0));
   printf("O Log10 de 10000 é %f\n", log10(10000.0));
}
