#include <stdio.h>

void tres_olas(void)
{
   int contador; // Variável 

   for (contador = 1; contador <= 3; contador++)
     printf("Oi pessoal!\n");
}
int main(void)
{
   tres_olas();
}
