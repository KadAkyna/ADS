#include <stdio.h>

void ola_pessoal(void)
{ 
   printf("Olá pessoal!\n");
}
int main(void)
{
   ola_pessoal();
}
