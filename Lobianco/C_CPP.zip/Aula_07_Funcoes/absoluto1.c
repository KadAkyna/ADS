#include <stdio.h>
#include <stdlib.h>

int main(void)
{
   printf("O valor absoluto de %d é %d\n", 5, abs(5));
   printf("O valor absoluto de %d é %d\n", 0, abs(0));
   printf("O valor absoluto de %d é %d\n", -5, abs(-5));
}
