#include <stdio.h>

int main(void)
{
   int contador = 1;  // Inicializa a vari�vel de controle

   while (contador <= 100)  // Testa a vari�vel de controle
   {
       printf("%d ", contador);  // Executa os comandos
       contador++;    // Modifica a vari�vel de controle
   }
}
