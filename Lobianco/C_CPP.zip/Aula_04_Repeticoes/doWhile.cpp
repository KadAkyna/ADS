#include <iostream>
using namespace std;

int main()
{
   int contador = 1;

   do
   {
      cout << contador << "  ";
   }
   while ( ++contador <= 10 );

   cout << endl;

   return 0;
}
