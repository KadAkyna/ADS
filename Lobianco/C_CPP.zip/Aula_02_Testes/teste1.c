#include <stdio.h>

void main(void)
{
   int idade = 21;

   if (idade == 21)
     printf("A idade do usuário é 21\n");

   if (idade != 21)
     printf("A idade do usuário não é 21\n");
}
