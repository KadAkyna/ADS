#include <iostream>

int main()
{
   std::cout << "Programação C/C++";

   return 0;
}
