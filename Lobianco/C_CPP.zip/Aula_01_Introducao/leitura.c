#include <stdio.h>

void main(void)
{
   int inteiro1, inteiro2, soma;

   printf("Digite o primeiro número\n");
   scanf("%d", &inteiro1);
   printf("Digite o segundo número \n";
   scanf("%d", &inteiro2);
   soma = inteiro1 + inteiro2;
   printf("A soma é %d\n", soma);
}
