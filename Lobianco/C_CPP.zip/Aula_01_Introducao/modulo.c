#include <stdio.h>

void main(void)
{
   int resto, resultado;

   resultado = 10 / 3;
   resto = 10 % 3;
   printf("10 dividido por 3 é %d \nResto é %d\n", resultado, resto);
}
