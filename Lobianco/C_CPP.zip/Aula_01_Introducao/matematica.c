#include <stdio.h>

void main(void)
{
   int segundos_na_hora;
   float media;

   segundos_na_hora = 60 * 60;
   media = (5 + 10 + 15 + 20) / 4;
   printf("Número de segundos em uma hora %d\n", segundos_na_hora);
   printf("A média de 5, 10, 15 e 20 é %f\n", media);
   printf("48 minutos possui %d segundos\n", segundos_na_hora  12*60);
}
