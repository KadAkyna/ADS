// Programa: COMENTARIO1.C
// Escrito por: xxx
// Data de criação: 01-01-2011
// Propósito: Ilustrar o uso de comentários em um programa C

#include <stdio.h>

void main(void)
{
   printf ("Programação C/C++");    // Exibe uma mensagem
}
