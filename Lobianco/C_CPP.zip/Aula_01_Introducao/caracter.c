#include <stdio.h>

void main(void)
{
   printf("A letra � %c\n", 'A');
   printf("A letra � %c\n", 65);
}
