#include <stdio.h>

void main(void)
{
   int valor = 255;

   printf("O valor decimal %d em octal é %o\n", valor, valor);
   printf("O valor decimal %d em hexadecimal é %x\n", valor, valor);
   printf("O valor decimal %d em hexadecimal é %X\n", valor, valor);
}
