#include <stdio.h>

void main(void)
{
   printf("Programação C/C++");
}
