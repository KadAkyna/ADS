#include <iostream>

int main()
{
   std::cout << "Programação\n\tC/C++\n\n";
   return 0; 
}
