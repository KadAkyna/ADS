void main(void)
{
   int idade;      // a idade do usuário em anos
   int peso;       // o peso do usuário em Kg
   int altura;     // a altura do usuário em centímetros

   idade = 41;     // atribui a idade ao usuário
   peso = 80;      // atribui o peso
   altura = 182;   // atribui a altura
}