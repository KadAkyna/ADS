#include <stdio.h>

void main(void)
{
   int valor = 5;

   printf ("%3d\n", valor);
   printf ("%03d\n", valor);
   printf ("%5d\n", valor);
   printf ("%05d\n", valor);
}
