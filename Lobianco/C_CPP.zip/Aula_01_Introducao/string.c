#include <stdio.h>

void main(void)
{
   char titulo[255] = "Programação C/C++";

   printf("O nome desta apostila é %s\n", titulo);
}
