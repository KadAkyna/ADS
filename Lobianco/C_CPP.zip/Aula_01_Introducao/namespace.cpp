#include <iostream>
using namespace std;

int main()
{
   int inteiro1, inteiro2, soma;

   cout << "Digite o primeiro número\n";
   cin >> inteiro1; 
   cout << " Digite o segundo número \n";
   cin >> inteiro2; 
   soma = inteiro1 + inteiro2;
   cout << "A soma é " << soma << endl;
   return 0;
}
