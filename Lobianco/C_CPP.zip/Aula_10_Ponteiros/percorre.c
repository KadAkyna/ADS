#include <stdio.h>

void exibe_string(char *string)
{
   while (*string)
     printf("%c,*string++);
}
int main(void)
{
   exibe_string("Aprendendo C/C++");
}

