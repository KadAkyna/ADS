Este é um arquivo de teste

contendo algumas linhas de texto

para realizar operações de arquivos
