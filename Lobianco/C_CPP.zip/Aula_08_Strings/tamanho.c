#include <stdio.h>
#include <string.h>

void main(void)
{
   char titulo_livro[] = "Programação C/C++";

   printf("%s contém %d caracteres\n",titulo_livro,strlen(titulo_livro));
}
